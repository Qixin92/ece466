echo "poisson traffic"
java TrafficGenerator localhost 
