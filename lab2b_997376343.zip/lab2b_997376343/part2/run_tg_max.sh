echo "excercise 2.4: generating traffic every 1 ms, 8 packets, 900 bytes each"
echo "rate = 7.2 Mbps"
java TrafficGeneratorReference localhost 1 8 1000
