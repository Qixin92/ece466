echo "time (msec), packet size B, backlog in buffer"
java TrafficScheduler
