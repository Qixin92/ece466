echo "experiment 1: generating traffic every 2 ms, 1 packet, 100 bytes each"
echo "rate = 0.4 Mbps"
java TrafficGeneratorReference localhost 2 1 100
