echo "video traffic"
java TrafficGeneratorVideo localhost 
