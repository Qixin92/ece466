echo "ethernet traffic"
java TrafficGeneratorEthernet localhost 
