echo "seqno, packet length, time to record"
java TrafficSink 4445
