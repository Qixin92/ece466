make clean
make
java TrafficSink 4444
