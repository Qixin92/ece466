echo "experiment 2: generating traffic every 10 ms, 10 packets, 100 bytes each"
echo "rate = 0.8 Mbps"
java TrafficGeneratorReference localhost 10 10 100
