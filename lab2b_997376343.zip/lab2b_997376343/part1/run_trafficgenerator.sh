echo "generating traffic every 1 ms, 5 packets, 10 bytes each"
java TrafficGeneratorReference localhost 1 5 10
