echo "experiment 3: generating traffic every 1 ms, 1 packets, 100 bytes each"
echo "rate = 0.8 Mbps"
java TrafficGeneratorReference localhost 1 1 100
