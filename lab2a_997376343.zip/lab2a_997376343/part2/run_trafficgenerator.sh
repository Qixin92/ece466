java TrafficGenerator localhost 
