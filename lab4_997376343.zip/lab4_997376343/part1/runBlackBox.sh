java BlackBox/BlackBox $1 $2
