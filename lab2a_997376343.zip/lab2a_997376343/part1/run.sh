make clean
make
java ReadFileWriteFile
