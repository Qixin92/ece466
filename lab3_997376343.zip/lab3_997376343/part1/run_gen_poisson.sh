echo "poisson traffic"
echo "seqNo, timetowait (nanosec), packet length"
java TrafficGeneratorPoissonRescale localhost $1 $2
